.include "equdefs.inc"
.global inbyte
.global inkey
.text
.even

inbyte:  
    link %a6, #-2
    movem.l %d1-%d3/%a0, -(%sp)
    
    /* #ローカル変数 1つ (4バイト) の領域をスタック上に確保 */ 
    
    /* 引数 channel (8(%a6)) を取得し %d1 に入れる */
    move.l 8(%a6), %d1
    
inbyte_loop:
    lea.l -1(%a6), %a0      /* ローカルスタック上のアドレスを %a0 に設定 */
    move.l %a0, %d2          
    /* ローカル作業領域のアドレスをシステムコール引数 %D2 (p) に設定 */
    move.l #SYSCALL_NUM_GETSTRING, %d0 /* Syscall ID = 1 (GETSTRING) */
    /* move.l #0, %d1          /* Channel = 0 */
    
    /* ローカル作業領域のアドレスをシステムコール引数 %D2 (p) に設定 */
    move.l #1, %d3          /* size = 1 */
    trap #0
    
    cmp.l #1, %d0
    bne inbyte_loop 
    
    move.l #0, %d0   
    
    move.b -1(%a6), %d0 
   
    
    
inbyte_finish:    
    movem.l (%sp)+, %d1-%d3/%a0
    unlk %a6 
    rts
    
inkey:
	/* スタックフレームの作成とバッファ確保 */
	/* %a6を保存し、%spを2バイト減らしてローカルバッファ領域(-2(%a6))を確保 */
	link    %a6, #-2

	movem.l %d2-%d3/%a0, -(%sp)
	move.l  #SYSCALL_NUM_GETSTRING, %d0
    
	/* 引数 ch をスタックから取得して %d1 にセット */
	move.l  8(%a6), %d1
    
	/* ローカルバッファのアドレス (-1(%a6)) を %d2 にセット */
	lea     -1(%a6), %a0
	move.l  %a0, %d2
	
	move.l  #1, %d3
	trap    #0

	/* %d0 には「実際に読み込んだバイト数」が入っている */
	tst.l   %d0
	bne     INKEY_SUCCESS   

	/* 失敗 */
	move.l  #-1, %d0        /* 戻り値を -1 (0xFFFFFFFF) に設定 */
	bra     INKEY_EXIT

INKEY_SUCCESS:
	/* 成功 */
	moveq   #0, %d0         /* 上位ビットをクリア */
	move.b  -1(%a6), %d0    /* バッファから1文字読み出し */

INKEY_EXIT:
	movem.l (%sp)+, %d2-%d3/%a0
	unlk    %a6             /* スタックフレームの破棄 */
	rts
	    
    
    

    
