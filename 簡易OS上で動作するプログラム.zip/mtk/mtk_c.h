#ifndef  MTK_C_H
#define  MTK_C_H

/* 定数の定義 */
#define  NULLTASKID    0
#define  NUMTASK       5
#define  NUMSEMAPHORE  3
#define  STKSIZE       1024
#define  UNDEFINED     0
#define  IN_USE        1
#define  TERMINATED    2
/*----------------------------------------
  カーネルで使用する構造体、変数の定義
----------------------------------------*/
typedef int TASK_ID_TYPE;

/* セマフォ構造体 */
typedef struct {
    int  count;
    int  nst;
    TASK_ID_TYPE  task_list;
} SEMAPHORE_TYPE;

/* タスクコントロールブロック構造体 */
typedef struct {
    void  (*task_addr)();
    void  *stack_ptr;
    int   priority;
    int   status;
    TASK_ID_TYPE  next;
} TCB_TYPE;

/* タスクスタック構造体 */
typedef struct {
    char  ustack[STKSIZE];
    char  sstack[STKSIZE];
} STACK_TYPE;

#ifdef MTK_C_DEFINE
/* 大域変数の定義 */           
TASK_ID_TYPE curr_task;                              /* 現在実行中のタスクの ID */
TASK_ID_TYPE new_task;                               /* 現在登録作業中のタスクの ID */
TASK_ID_TYPE next_task;                              /* 次に実行するタスクの ID */
TASK_ID_TYPE ready;                         /* 実行待ちタスクのキュー */
SEMAPHORE_TYPE semaphore[NUMSEMAPHORE];     /* セマフォの配列 */
TCB_TYPE      task_tab[NUMTASK+1];          /* タスクコントロールブロックの配列 */
STACK_TYPE    stacks[NUMTASK];              /* タスクスタックの配列 */

#else
/* 大域変数の宣言 */
extern TASK_ID_TYPE curr_task;                               /* 現在実行中のタスクの ID */
extern TASK_ID_TYPE new_task;                                /* 現在登録作業中のタスクの ID */
extern TASK_ID_TYPE next_task;                               /* 次に実行するタスクの ID */
extern TASK_ID_TYPE ready;                          /* 実行待ちタスクのキュー */
extern SEMAPHORE_TYPE semaphore[NUMSEMAPHORE];      /* セマフォの配列 */
extern TCB_TYPE      task_tab[NUMTASK+1];           /* タスクコントロールブロックの配列 */
extern STACK_TYPE    stacks[NUMTASK];               /* タスクスタックの配列 */

#endif

/* 外部関数の宣言 */
void           init_kernel();
int            set_task();
void*          init_stack(); /* ? */
void           begin_sch();
void           addq();
TASK_ID_TYPE   removeq();
void           sched();
void           sleep();
void           wakeup();
void           p_body();
void           v_body();
void           waitp_body();
void           skipmt();
extern void pv_handler();
extern void init_timer();
extern void first_task();
extern void swtch();
extern void P();
extern void V();
extern void waitP();
extern void skipmt();
extern int inkey();
      
#endif

