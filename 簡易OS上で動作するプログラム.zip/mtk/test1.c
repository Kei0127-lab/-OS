#include <stdio.h>
void exit(int value) {
*(char *)0x00d00039 = 'H'; 
for (;;); 
}


int main(void){
    while(1){
        printf("入力してください\n");
        
        char str[16];
        scanf("%s",str); 
        printf("入力された文字：%s\n",str);
        
        
        
    }
}
