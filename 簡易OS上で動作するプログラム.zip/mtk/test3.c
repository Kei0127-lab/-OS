#include "mtk_c.h"
#include <stdio.h>
#include <string.h>

/* Semaphores (0..2 only) */
#define SEM_UART1   0   /* UART1 output (com0out) */
#define SEM_UART2   1   /* UART2 output (com1out) */
#define SEM_SHARED  2   /* shared state */

FILE *com0in;  FILE *com0out; /* fd=3 */
/* FILE *com1in;  FILE *com1out;  fd=4 */
void fdstream(void){
    com0in  = fdopen(3, "r");
    com0out = fdopen(3, "w");
    /*com1in  = fdopen(4, "r");
    com1out = fdopen(4, "w");*/
}

/* Areas / Faults */
typedef enum { BRIDGE=0, ENGINE, REACTOR, LIFE, CORRIDOR, AREA_N } Area;
static const char *AREA_NAME[AREA_N] = { "bridge","engine","reactor","life","corridor" };

#define F_ENGINE   (1u<<ENGINE)   
#define F_LIFE     (1u<<LIFE)     
#define F_REACTOR  (1u<<REACTOR) 
#define F_CORRIDOR (1u<<CORRIDOR) 

/* Game params */
#define OXY_INIT  100
#define HULL_INIT 100
#define CLEAR_TICK 60
#define BUSY_1SEC_LOOP 35000

/* Shared state (guard with SEM_SHARED) */
volatile int oxygen = OXY_INIT;
volatile int hull   = HULL_INIT;
volatile unsigned int tick = 0;
volatile unsigned int faults = 0;
volatile int game_over = 0;
volatile int game_clear = 0;

/* position (unified) */
volatile Area pos;                
/* RNG state */
volatile unsigned int rng_state = 0x13579BDFu;

volatile unsigned int task_done;  

volatile int healing = 0;   /* hull回復中か */

/* Repair tasks (separate per player) */
typedef enum { RT_NONE=0, RT_KEY, RT_CALC, RT_TYPE } RepairType;

typedef struct {
    int active;
    RepairType type;
    Area target;

    /* KEY */
    char key_ch;
    int  key_need;
    int  key_count;

    /* CALC */
    int  a, b;
    char op;
    int  answer;

    /* TYPE */
    char type_buf[8];
    const char *word;
} RepairTask;

static RepairTask rt;
static RepairType last_repair_type = RT_NONE;

/* Game Over */
typedef enum {
    DEAD_NONE = 0,
    DEAD_OXYGEN,
    DEAD_HULL
} DeadCause;

volatile DeadCause dead_cause;

/* Output helpers (minimal UI) */
static void out(const char *s){ 
    P(SEM_UART1); 
    fputs(s, com0out); 
    fflush(com0out); 
    V(SEM_UART1); 
}

static void prompt(void){
    out("P0> ");
}


/* Game Result */
static void print_result(void){
    char buf[128];

    if(game_over){
        out("\r\n=== GAME OVER ===\r\n");
       
        if(dead_cause == DEAD_OXYGEN){
            out("Cause: Oxygen depleted\r\n");
        } else if(dead_cause == DEAD_HULL){
            out("Cause: Ship destroyed\r\n");
        }
    }
    else if(game_clear){
        out("\r\n=== GAME CLEAR ===\r\n");
    }

    snprintf(buf, sizeof(buf),
             "P0 tasks completed: %u\r\n", task_done);
    out(buf);

}

/* Utils */
static void trim_nl(char *s){
    size_t n = strlen(s);
    while(n && (s[n-1]=='\n' || s[n-1]=='\r')) { s[n-1]='\0'; n--; }
}
static int starts_with(const char *s, const char *pfx){
    return strncmp(s, pfx, strlen(pfx)) == 0;
}
static void str_to_lower(char *s){
    for(int i=0; s[i]; i++){
        if('A' <= s[i] && s[i] <= 'Z') s[i] = (char)(s[i] - 'A' + 'a');
    }
}
static Area parse_area(const char *name){
    for(int i=0;i<AREA_N;i++){
        if(strcmp(name, AREA_NAME[i])==0) return (Area)i;
    }
    return AREA_N;
}
static int popcnt(unsigned int x){
    int c=0; while(x){ c += (x&1u); x >>= 1; } return c;
}
static int calc_eval(int a,int b,char op){
    if(op=='+') return a+b;
    if(op=='-') return a-b;
    return a*b;
}

/* Locked accessors */
static Area get_pos_locked(void){
        return pos;
}

static void set_pos_locked(Area a){
        pos = a;
}

static void print_initial_position(void){
    char buf[64];

    P(SEM_SHARED);
    Area p = pos;
    V(SEM_SHARED);

    const char *name = (p < AREA_N) ? AREA_NAME[p] : "unknown";
    snprintf(buf, sizeof(buf),
             "\r\n[INIT] You are at %s\r\n", name);
    out(buf);
}

/* RNG (locked only) */
static unsigned int prand_locked(void){
    rng_state = rng_state * 1664525u + 1013904223u;
    return rng_state;
}

/* Announce faults (short) */
static void announce_fault(unsigned int bit){
    if(bit==F_ENGINE){  out("\r\n! ENGINE\r\n"); }
    if(bit==F_LIFE){    out("\r\n! LIFE\r\n"); }
    if(bit==F_REACTOR){ out("\r\n! REACTOR\r\n"); }
    if(bit==F_CORRIDOR){out("\r\n! FIRE\r\n"); }
}

/* Repair task start/print (locked start) */
static void start_repair_task_locked(Area target){
    RepairType pick;
    unsigned int r;
    
    do {
       r = prand_locked();
       switch (r % 3u) {
           case 0: pick = RT_KEY;  break;
           case 1: pick = RT_CALC; break;
           default: pick = RT_TYPE; break;
       }
    } while (pick == last_repair_type);

    RepairTask *t = &rt;
    *t = (RepairTask){0};

    t->active = 1;
    t->target = target;
    t->type   = pick;
    
    last_repair_type = pick;
    
    if(t->type == RT_KEY){
        t->key_ch = 'a' + (prand_locked() % 26);
        t->key_need  = (int)(prand_locked() % 5u) + 6;
        t->key_count = 0;
    } else if(t->type == RT_CALC){
        t->a = (int)(prand_locked() % 90u) + 10;
        t->b = (int)(prand_locked() % 90u) + 10;
        
        unsigned int rop = prand_locked(); 
        
        switch (rop % 3u) {
             case 0: t->op = '+'; break;
             case 1: t->op = '-'; break;
             default: t->op = '*'; break;
        }
        
        t->answer = calc_eval(t->a, t->b, t->op);
        
    } else {
        for(int i=0; i<5; i++){
            unsigned int r2 = prand_locked() % 36u;
            t->type_buf[i] = (r2 < 10) ? ('0' + r2) : ('A' + (r2 - 10));
    }
    t->type_buf[5] = '\0';
    t->word = t->type_buf;
  } 
}

static void print_task(void){
    char m[96];
    RepairTask *t = &rt;

    if(t->type == RT_KEY){
        snprintf(m, sizeof(m), "\r\nTASK: '%c'x%d  (/cancel)\r\n", t->key_ch, t->key_need);
    } else if(t->type == RT_CALC){
        snprintf(m, sizeof(m), "\r\nTASK: %d%c%d=?  (/cancel)\r\n", t->a, t->op, t->b);
    } else {
        snprintf(m, sizeof(m), "\r\nTASK: type %s  (/cancel)\r\n", t->word);
    }
    out(m);
}

/* Repair input handler (no locks needed) return 1 if completed */
static int handle_repair_input(RepairTask *t, const char *line){
    if(strcmp(line, "/cancel")==0){
        t->active = 0;
        return 0;
    }
    if(t->type == RT_KEY){
        int add=0;
        for(int i=0; line[i]; i++) if(line[i]==t->key_ch) add++;
        t->key_count += add;
        return (t->key_count >= t->key_need);
    } else if(t->type == RT_CALC){
        int x;
        return (sscanf(line, "%d", &x)==1 && x==t->answer);
    } else {
        return (t->word && strcmp(line, t->word)==0);
    }
}

/* Fault clear (locked) */
static void clear_fault_locked(Area a){
    faults &= ~(1u<<a);
}

/* Fault spawn (locked, NO nested SEM_SHARED) */
static unsigned int choose_fault_locked(void){
    unsigned int r = prand_locked();
    unsigned int cand[] = { F_ENGINE, F_LIFE, F_REACTOR, F_CORRIDOR };
    return cand[r % 4u];
}

static void try_spawn_fault_once(void){
    unsigned int pick = 0;

    P(SEM_SHARED);
    int nfaults = popcnt(faults);    

    if(!game_over && !game_clear && tick < CLEAR_TICK 
       && nfaults < 3 && (tick % 3u) == 0u){
        int prob;

        if(healing){
            prob = 4;   /* 5/8 ≒ 62% */
        } else {
            prob = 2;   /* 2/8 = 25% */
        }

        if((prand_locked() & 7u) < prob){
            pick = choose_fault_locked();
            if((faults & pick) == 0u){
                faults |= pick;
            } else {
                pick = 0;
            }
        }
    }    
   
    V(SEM_SHARED);

    if(pick) announce_fault(pick);
}

/* status (only info command) */
static void do_status(void){
    char b[128];
    P(SEM_SHARED);
    int o = oxygen, h = hull;
    unsigned int t = tick;
    unsigned int f = faults;
    V(SEM_SHARED);

    snprintf(b, sizeof(b), "\r\nT=%us O2=%d H=%d\r\n",
             (unsigned int)t, o, h);
    out(b);
    
    out("FAULTS: ");

    if(f == 0){
        out("NONE");
    } else {
        int first = 1;

        if(f & F_ENGINE){
            out(first ? "ENGINE" : ", ENGINE");
            first = 0;
        }
        if(f & F_LIFE){
            out(first ? "LIFE" : ", LIFE");
            first = 0;
        }
        if(f & F_REACTOR){
            out(first ? "REACTOR" : ", REACTOR");
            first = 0;
        }
        if(f & F_CORRIDOR){
            out(first ? "CORRIDOR(FIRE)" : ", CORRIDOR(FIRE)");
        }
    }

    out("\r\n");
    if(healing) out("HEAL: ON\r\n");

}


/* move */
static void do_move(const char *arg){
    char a[24];
    strncpy(a, arg, sizeof(a));
    a[sizeof(a)-1] = '\0';
    str_to_lower(a);

    Area dst = parse_area(a);
    if(dst == AREA_N){
        out("\r\n(BAD AREA)\r\n");
        return;
    }

    P(SEM_SHARED);
    healing = 0;  

    if(faults & F_CORRIDOR){
        V(SEM_SHARED);
        out("\r\n(MOVE BLOCK: FIRE)\r\n");
        return;
    }
 
    set_pos_locked(dst);
    V(SEM_SHARED);

    out("\r\n(MOVED)\r\n");
}

/* repair */
static void start_repair_at(Area target){
    P(SEM_SHARED);
    healing = 0;  

    if(rt.active){
        V(SEM_SHARED);
        out("\r\n(ALREADY)\r\n");
        return;
    }/* already repairing? */

    if(!(faults & (1u<<target))){
        V(SEM_SHARED);
        out("\r\n(NOTHING)\r\n");
        return;
    }/* must be a fault here */

    start_repair_task_locked(target);
    V(SEM_SHARED);

    print_task();
}

/* help */
static void do_help(void){
    out("\r\nCMD: /status, /move <area>, /repair, /extinguish, /cancel, /help, /heal\r\n");
    out("AREA: bridge engine reactor life corridor\r\n");
}

/* start hull healing */
static void do_heal(void){
    P(SEM_SHARED);

    if(healing){
        V(SEM_SHARED);
        out("\r\n(ALREADY HEALING)\r\n");
        return;
    }

    if(rt.active){
        V(SEM_SHARED);
        out("\r\n(CANNOT HEAL: BUSY)\r\n");
        return;
    }

    if(hull >= HULL_INIT){
        V(SEM_SHARED);
        out("\r\n(HULL FULL)\r\n");
        return;
    }

    healing = 1;

    V(SEM_SHARED);
    out("\r\n(HEALING STARTED)\r\n");
}

/* Player task (shared structure) */
static void player_loop(FILE *in){
    char line[96];

    out("\r\nPlayer READY\r\n");
    print_initial_position();
    do_help();
    prompt();

    while(1){
        if(!fgets(line, sizeof(line), in)){ skipmt(); continue; }
        trim_nl(line);

        /* repair mode? */
        if(rt.active){
            if(handle_repair_input(&rt, line)){
                /* completed */
                P(SEM_SHARED);
                clear_fault_locked(rt.target);
                rt.active = 0;
                task_done++;
                V(SEM_SHARED);
                out("\r\n(OK)\r\n");
            } else {
                if(!rt.active) out("\r\n(CANCEL)\r\n");
                else               out("\r\n...\r\n");
            }
            prompt();
            skipmt();
            continue;
        }
        
        /* command mode */
        if(line[0] == '/'){
            if(starts_with(line, "/status")){
                do_status();
            } else if(starts_with(line, "/help")){
                do_help();
            }
            else {
                P(SEM_SHARED);
                int ended = (game_over || game_clear);
                V(SEM_SHARED);
                
                if(ended){
                    out("\r\n(GAME ENDED)\r\n");
                }
                else if(starts_with(line, "/move")){
                    char a[24];
                    if(sscanf(line, "/move %23s", a)==1) do_move(a);
                    else out("\r\nUSE: /move <area>\r\n");
                } else if(starts_with(line, "/repair")){
                    Area p;
                    P(SEM_SHARED);
                    p = get_pos_locked();
                    V(SEM_SHARED);
                    start_repair_at(p);
                } else if(starts_with(line, "/extinguish")){
                    start_repair_at(CORRIDOR);
                } else if(starts_with(line, "/heal")){
                    do_heal();
                } else {
                    out("\r\n(UNKNOWN)\r\n");
                }
            }
            prompt();
            skipmt();
            continue;
        }

        /* chat removed: ignore */
        out("\r\n(NOP)\r\n");
        prompt();
        skipmt();
    }
}

void task_player0(void){ player_loop(com0in); }

/* Timer task */
void task_timer(void){
    int result_printed=0;
      
    while(1){
        for(volatile int i=0;i<BUSY_1SEC_LOOP;i++);
        
        
        P(SEM_SHARED);
        if(!game_over && !game_clear) {
            tick++;
     
            if(faults & F_ENGINE)  oxygen -= 2;
            if(faults & F_LIFE)    oxygen -= 2;
            if(faults & F_REACTOR) hull   -= 2;
            if(faults & F_CORRIDOR){
                hull   -= 1;   /* 火災による構造損傷 */
                oxygen -= 1;   /* 火災による酸素消費・漏洩 */
            }
           
            if(healing){
                if(rt.active || game_over || game_clear){
                    healing = 0;   /* 条件崩れで停止 */
                } else {
                    hull += 1;
                    if(hull > HULL_INIT) hull = HULL_INIT;

                    if(hull >= HULL_INIT){
                        healing = 0;   /* 満タンで自動停止 */
                    }
                }
            }

            if(!(faults & (F_LIFE | F_ENGINE)) && !rt.active) {
                 oxygen += 1;
            }

            if(oxygen < 0) oxygen = 0;
            if(oxygen > OXY_INIT) oxygen = OXY_INIT;
            if(hull   < 0) hull   = 0;

            if(oxygen<=0) {
                game_over = 1;
                dead_cause = DEAD_OXYGEN;
                rt.active = 0; 
                healing = 0;   
            } else if(hull<=0) {
                game_over = 1;
                dead_cause = DEAD_HULL;
                rt.active = 0; 
                healing = 0;   
            }
 
            if(!game_over && tick>=CLEAR_TICK && faults==0) {
                game_clear = 1;
                healing = 0;   
                rt.active = 0; 
            }
            
            rng_state ^= (unsigned int)tick + (faults<<16);/* keep rng moving */
      }
      V(SEM_SHARED);
        
      if(!result_printed && (game_over || game_clear)){
          result_printed = 1;
          print_result();  
      }

          skipmt();
   }
}

/* Event task (no nested SEM_SHARED) */
void task_event(void){
    while(1){
        for(volatile int i=0;i<20000;i++);
        try_spawn_fault_once();
        skipmt();
    }
}

/* main */
void main(void){
    init_kernel();
    fdstream();

    semaphore[SEM_UART1].count  = 1;
    semaphore[SEM_UART2].count  = 1;
    semaphore[SEM_SHARED].count = 1;

    P(SEM_SHARED);
    oxygen = OXY_INIT;
    hull   = HULL_INIT;
    tick = 0;
    game_over = 0;
    game_clear = 0;
    dead_cause = DEAD_NONE;
    rt.active = 0;
    rng_state = 0x13579BDFu;
    task_done = 0;
    healing = 0;
    
    {
        Area p;
        do {
            p = (Area)(prand_locked() % AREA_N);
        } while (p == CORRIDOR);

        pos = p;
    }
    
    faults = 0;   
    {
        int n_init = (prand_locked() & 1u) ? 2 : 1;

        while (popcnt(faults) < n_init) {
            unsigned int f = choose_fault_locked();

            if (f == F_CORRIDOR) continue; /* 初期火災は禁止 */

            if (f == (1u << pos)) continue;  /* 初期位置と同じ場所は禁止 */

            if ((faults | f) == (F_LIFE | F_ENGINE)) continue;  /* LIFE + ENGINE 同時は禁止 */

            faults |= f;
        }
    }
    V(SEM_SHARED);

    if (faults & F_ENGINE)   announce_fault(F_ENGINE);
    if (faults & F_LIFE)     announce_fault(F_LIFE);
    if (faults & F_REACTOR)  announce_fault(F_REACTOR);
    if (faults & F_CORRIDOR) announce_fault(F_CORRIDOR);
    
    set_task(task_player0);
    set_task(task_timer);
    set_task(task_event);

    begin_sch();
}
