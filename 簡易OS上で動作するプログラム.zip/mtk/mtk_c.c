#define  MTK_C_DEFINE
#include "mtk_c.h"
#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>
#include <fcntl.h>

void init_kernel() {
	for (int i = 1; i <= NUMTASK; i++) { /* TCB配列の初期化 */
		task_tab[i].next = NULLTASKID;
	}
	
	ready = NULLTASKID; /* readyキューの初期化 */
	
	char *p = (char *)0x00000084; /* trap#1の設定 */
	unsigned long trapinit = (unsigned long) pv_handler;
	p[0] = (trapinit >> 24) & 0xFF;
	p[1] = (trapinit >> 16) & 0xFF;
	p[2] = (trapinit >> 8) & 0xFF;
	p[3] = trapinit & 0xFF; 
	
	for (int i = 0; i < NUMSEMAPHORE; i++) { /* セマフォの初期化 */
		semaphore[i].count = 1;
		semaphore[i].nst = 0; /* ? */
		semaphore[i].task_list = NULLTASKID;
	}
}

int set_task(void (*task_addr)()){
    int i;
    /* 1. タスクIDの決定 */
    for (i = 1; i < NUMTASK; i++){
        if (task_tab[i].status == UNDEFINED){
            new_task = i;
            break;
        }
    }
    
    if (i == NUMTASK){
        return -1;
    }
    
    /* 2. TCB の更新 */
    task_tab[new_task].task_addr = task_addr;
    task_tab[new_task].status    = IN_USE;

    /* 3. スタックの初期化 */
    task_tab[new_task].stack_ptr = init_stack(new_task); 
    
    /* 4. キューへの登録 */
    addq(&ready, new_task);

    return new_task;
}

void begin_sch(){
    /* 1. 最初のタスクの決定 */
    curr_task = removeq(&ready);
    
    /* 2. タイマの設定 */
    init_timer();  
    
    /* 3. 最初のタスクの起動 */
    first_task();
}

void* init_stack(int id) {
	char *p = stacks[id - 1].sstack;
	
	/* SRの初期化 */
	p[STKSIZE - 6] = 0x00;
	p[STKSIZE - 5] = 0x00;
	
	/* PCの初期化 */
	unsigned long pcinit = (unsigned long) task_tab[id].task_addr;
	
	p[STKSIZE - 4] = (pcinit >> 24) & 0xFF;
	p[STKSIZE - 3] = (pcinit >> 16) & 0xFF;
	p[STKSIZE - 2] = (pcinit >> 8) & 0xFF;
	p[STKSIZE - 1] = pcinit & 0xFF;
	
	/* USPの初期化 */
	unsigned long uspinit = (unsigned long) &stacks[id - 1].ustack[STKSIZE];
	
	p[STKSIZE - 70] = (uspinit >> 24) & 0xFF;
	p[STKSIZE - 69] = (uspinit >> 16) & 0xFF;
	p[STKSIZE - 68] = (uspinit >> 8) & 0xFF;
	p[STKSIZE - 67] = uspinit & 0xFF;
	
	return &p[STKSIZE - 70];
}

void sched() {
	TASK_ID_TYPE scheder = NULLTASKID;
	while (scheder == NULLTASKID) {
		scheder = removeq(&ready); /* removeqの仕様によっては変更するかも */
	}
	next_task = scheder;
}

void addq(TASK_ID_TYPE *queue, TASK_ID_TYPE id){
    TASK_ID_TYPE q = *queue;

    if (q == NULLTASKID) {
        *queue = id;               
    } else {
        while (task_tab[q].next != NULLTASKID) {
            q = task_tab[q].next;
        }
        
        task_tab[q].next = id;
    }

    task_tab[id].next = NULLTASKID; 
}

TASK_ID_TYPE removeq(TASK_ID_TYPE *queue){
    TASK_ID_TYPE id = *queue;

    if (id == NULLTASKID) {
        return NULLTASKID;
    }

    *queue = task_tab[id].next;

    task_tab[id].next = NULLTASKID;

    return id;
}

void sleep(TASK_ID_TYPE ch) { // ch はここではセマフォID
    // 現行タスク (curr_task)  -> チャンネル (セマフォ) の待ち行列
    addq(&semaphore[ch].task_list, curr_task); 

    sched();
    
    swtch(); 
}

void wakeup(int ch) {
    TASK_ID_TYPE woken_task_id;//変数定義

    woken_task_id = removeq(&semaphore[ch].task_list);

    if (woken_task_id != NULLTASKID) {
        addq(&ready, woken_task_id);
       
    }
}

void p_body(TASK_ID_TYPE sem_id) {
    SEMAPHORE_TYPE *sp = &semaphore[sem_id];     // 1. セマフォ構造体へのポインタを取得
    sp->count--;                                 // 2. セマフォの値を1減らす

    // カウンタが負であれば、タスクを休眠状態にする
    if (sp -> count < 0) { 
        
        sleep(sem_id); 
    }
    // カウンタが0以上であれば、そのまま続行
}

void v_body(int sem_id) {

    semaphore[sem_id].count++;

//セマフォの値が0以下であればwakeup() を実行して実行可能状態にする
    if (semaphore[sem_id].count <= 0) {
        wakeup(sem_id);
    }
}


void waitp_body(TASK_ID_TYPE sem_id) {
    SEMAPHORE_TYPE *sp = &semaphore[sem_id];     

    // 1. カウンタが -(N-1) より大きい場合は、まだ全員揃っていないので休眠
    if (sp->count > -(sp->nst - 1)) {
        sp->count--;      // カウンタを減らす
        sleep(sem_id);    // タスクを休眠させる
    } 
    // 2. カウンタが -(N-1) に達した（最後の1人が来た）場合
    else {
        // 待たせていた N-1 個のタスクを ready キューへ戻す
        for(int k = 0; k < sp->nst - 1; k++) {
            wakeup(sem_id); 
            sp->count++;  // カウンタを 0 に戻していく
        }

        // 自分自身（N番目のタスク）も ready キューに追加して交代
        addq(&ready, curr_task);
        sched();
        swtch();
    }
}


int fcntl(int fd, int cmd,...) {
	if (cmd == F_GETFL) {
		return O_RDWR;
	}	
	else {
		return 0;
	}
}

