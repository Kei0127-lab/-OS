#include <stdio.h>
#include "mtk_c.h"

int i;

void task1(){
    while(1){
        P(0);
        for(i= 0; i<150000; i++){}
        printf("Hello,World\n");
        V(0);
    }
}

void task2(){
    while(1){
        P(0);
    	char str[16];
    	scanf("%s", str);
    	printf("%s\n", str);
        V(0);
    }
}

int main(){
     init_kernel();
     set_task(task1);
     set_task(task2);
     begin_sch();
     
     return 0;
}
