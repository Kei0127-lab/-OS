.include "equdefs.inc"
.section .text
.global first_task
.global swtch
.global hard_clock
.global init_timer
.global pv_handler
.global P
.global V
.global waitP
.global skipmt
.extern next_task
.extern curr_task
.extern task_tab
.extern p_body
.extern v_body
.extern waitp_body
.extern skipmt

    .even
first_task:
    /* Step 1: TCB先頭番地の計算  curr_task (ID) から TCB のアドレスを求める  */
    move.l  curr_task, %d0      /* 現在のタスクIDをロード */

    /* TCB_TYPEのサイズ計算 */
    mulu.w  #20, %d0            /* オフセット計算: ID * 20 */
    move.l   #task_tab, %a0       /* TCB配列の先頭アドレス */
    adda.l   %d0, %a0            /* A0 = &task_tab[curr_task] */

    /* Step 2: USP, SSP の回復  TCBに保存されたSSPをロードし、スタックを切り替える */
    move.l  4(%a0), %sp         /* SSPを回復 (A0 + 4bytes) */
    move.l  (%sp)+, %a1         /* スタックからUSPの値を取り出す */
    move.l  %a1, %usp           /* USPレジスタに設定 */

    /* Step 3: 残りの全レジスタの回復  D0-D7, A0-A6 (15本) をスタックから復帰 */
    movem.l (%sp)+, %d0-%d7/%a0-%a6

    /* Step 4: ユーザタスクの起動, スタックに残っている SR と PC を RTE で戻して遷移 */
    rte                         /* ユーザモードへ移行し、タスク開始 */

swtch:
	move.w %SR, -(%SP) /* SRをスタックに積む(rteで復帰するため) */
	
	movem.l %d0-%d7/%a0-%a6, -(%SP) /* レジスタの退避 */
	
	move.l %usp, %a1 /* uspの退避 */
	move.l %a1, -(%SP)
	
	move.l curr_task, %d0 /* TCBの発見 */
	mulu.w #20, %d0
	move.l #task_tab, %a0
	adda.l %d0, %a0
	
	move.l %SP, 4(%a0)/* SSPの記録 */
	
	move.l next_task, curr_task /* curr_taskの変更 */
	
	move.l curr_task, %d0 /* TCBの発見 */
	mulu.w #20, %d0
	move.l #task_tab, %a0
	adda.l %d0, %a0
	
	move.l 4(%a0), %SP /* SSPの回復 */
	
	move.l (%SP)+, %a1 /* uspの回復 */
	move.l %a1, %usp
	
	movem.l (%SP)+, %d0-%d7/%a0-%a6 /* レジスタの回復 */
	 
	rte

*hard_clock:タイマ割り込みルーチン
**このルーチンは割り込み駆動であるが，前期作成のタイマ用ハードウェア割込み処理インタフェースから呼び出されるため，RTS で復帰する．
**タイマ割り込みで実行されるルーチンであるため，退避し忘れたレジスタがあると予期せぬエラーとなり非常にデバッグが困難である．十分に注意すること．


hard_clock:
	/* レジスタ退避 */
	movem.l	%d0-%d7/%a0-%a6,-(%SSP)

	/* addq() により，curr_task(現在実行中のタスクの ID) を ready(実行待ちタスクのキュー) の末尾に追加 */
	move.l	#ready,	%d0
	move.l	(curr_task), %d1
	
	movem.l	%d0-%d1, -(%SSP)
	jsr	addq
	movem.l	(%SSP)+, %d0-%d1
	
	/* sched を起動 (次に実行されるタスクの ID が next_task にセットされる) */
	jsr	sched
	
	/* swtch を起動 */
	jsr	swtch

	/* レジスタの復帰 */
	movem.l	(%SSP)+, %d0-%d7/%a0-%a6
	rts


**クロック割り込みルーチン hard clock をベクトルテーブルに登録するルーチン．
**モニタのシステムコール TRAP #0 を利用する
**前期に作成したタイマ制御ルーチンを用いて，タイマによるハードウェア割り込みが発生するように作成する．割り込み周期は任意である．参考値として，Linux などでは 10ms 周期である．タイマによるタスク切替えの動作確認時は 1 秒程度の人が知覚できる周期が適当だと考える．


**SYSCALL_NUM_RESET_TIMER, 3
**SYSCALL_NUM_SET_TIMER, 4

init_timer:
	movem.l	%d0-%d2, -(%sp)
	
	** システムコールによる RESET_TIMER の起動
	move.l	#3, %d0
	trap	#0
	
	** システムコールによる SET_TIMER の起動
	move.l	#4, %d0
	move.w #10000, %d1	/* タイマ割り込み周期を1秒に設定 */
	move.l #hard_clock, %d2	/* ジャンプ先を hard_clock に設定 */
	trap #0
	
	movem.l	(%sp)+, %d0-%d2
	rts

pv_handler:
    movem.l %a0-%a1/%d2-%d7, -(%sp)
    
    move.w %SR, -(%sp)
    move.w #0x2700, %SR
    
    movem.l  %d1, -(%sp)     /* D1 (セマフォID)を引数としてスタック */
    
    cmpi.l #0, %d0
    beq P_Call
    
    cmpi.l #1, %d0
    beq V_Call
    
    cmpi.l #2, %d0
    beq WP_Call
    
    bra pv_finish
    
P_Call:
    jsr     p_body              
    bra   pv_finish
    
V_Call:
    jsr     v_body  
    bra   pv_finish
    
WP_Call:
    jsr    waitp_body
    
pv_finish:
    addq.l  #4, %sp
    move.w  (%sp)+, %SR
    movem.l (%sp)+, %a0-%a1/%d2-%d7
    rte             
    
P:
    /* SP+4 の場所にあるのでは？？？ */
    move.l  4(%SP), %d1   /* セマフォID　-> d1へ   */
    moveq.l #SYSCALL_ID_P, %d0  /* システムコールID　-> d0 */
    TRAP    #1
    
    rts
    
V:
    /*V システムコールの ID（１とする）を D0 レジスタに*/
    move.l  #1, %d0

    /*スタックから取り出した引数（セマフォID）を D1 レジスタに*/
    move.l  4(%sp), %d1

    trap    #1
    rts
    
waitP:
    move.l  4(%SP), %d1   /* セマフォID　-> d1へ   */
    move.l  #SYSCALL_ID_WP, %d0 
  
    trap    #1 
    
    rts
    

skipmt:
    movem.l %d0, -(%sp)
    /* システムコール番号5を D0 にセット */
    move.l  #5, %d0
    trap    #0
    
    movem.l (%sp)+, %d0
    rts
