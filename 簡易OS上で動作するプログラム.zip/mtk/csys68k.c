#include <fcntl.h>
#include <errno.h>

/* プロトタイプの変更: ポート番号を指定できるようにする */
extern void outbyte(int channel, unsigned char c);
extern char inbyte(int channel);

int read(int fd, char *buf, int nbytes)
{
  char c;
  int  i;
  int  channel;

  /* デバイスマッピング */
  if (fd >= 0 && fd <= 3) {
    channel = 0; // UART1
  } else if (fd == 4) {
    channel = 1; // UART2
  } else {
    return -1;
  }

  for (i = 0; i < nbytes; i++) {
    c = inbyte(channel); // channelを指定

    if (c == '\r' || c == '\n'){
      outbyte(channel, '\r');
      outbyte(channel, '\n');
      *(buf + i) = '\n';
    } else if (c == '\x7f'){
      if (i > 0){
        outbyte(channel, '\x8');
        outbyte(channel, ' ');
        outbyte(channel, '\x8');
        i--;
      }
      i--;
      continue;
    } else {
      outbyte(channel, c);
      *(buf + i) = c;
    }

    if (*(buf + i) == '\n'){
      return (i + 1);
    }
  }
  return (i);
}

int write (int fd, char *buf, int nbytes)
{
  int i;
  int channel;

  /* デバイスマッピング */
  if (fd >= 0 && fd <= 3) {
    channel = 0;
  } else if (fd == 4) {
    channel = 1;
  } else {
    return -1;
  }

  for (i = 0; i < nbytes; i++) {
    if (*(buf + i) == '\n') {
      outbyte (channel, '\r');
    }
    outbyte (channel, *(buf + i));
  }
  return (nbytes);
}


