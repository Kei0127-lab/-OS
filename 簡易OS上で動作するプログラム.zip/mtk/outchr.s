.include "equdefs.inc"
    .section .text
    .global outbyte

outbyte:
    link %a6, #-2           
    
    movem.l %d0-%d3/%a0, -(%sp) 
    
    move.l  8(%a6), %d1        /* D1 = channel */
    move.b  15(%a6), %d0       /*引数(char)をD0に読み込み (D0.L = 0x000000XX)*/
    
    move.l  12(%a6), %d0
    move.b  %d0, -1(%a6)    /* ローカル領域に書き込み */ 

outbyte_loop:
    move.l  #2, %d0  /*Syscall ID = 2 (PUTSTRING) */
    /* move.l  #0, %d1           /* Channel = 0 */
    lea.l   -1(%a6), %a0      /* A0 = バッファのアドレス (-1(%a6)) */    
    move.l  %a0, %d2          /* D2 = バッファのアドレス (-4(%a6)) */
    move.l  #1, %d3           /* Size = 1 */
    
    trap    #0

    cmp.l   #0, %d0
    beq     outbyte_loop      
    movem.l (%sp)+, %d0-%d3/%a0 
    unlk    %a6            
    rts
